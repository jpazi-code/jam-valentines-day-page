"use client";

import React from "react";

export function Header47() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="flex flex-col gap-5 md:flex-row md:gap-12 lg:gap-20">
          <div className="w-full max-w-lg">
            <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
              Our Cherished Moments
            </h1>
          </div>
          <div className="w-full max-w-lg">
            <p className="md:text-md">
              PLEASE BEAR WITH ME, ITS SO TEDIOUS TO ADD ALL THESE PICS SO ITO
              LANG MUNA
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
